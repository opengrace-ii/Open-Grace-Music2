/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Search,
  Sparkles,
  FolderOpen,
  Clipboard,
  Loader2,
  KeyRound,
  AlertCircle,
  Play,
  Pause,
  Radio,
  ListMusic,
  Plus,
  X,
  Bell,
} from 'lucide-react';
import {
  AUDIOPHILE_FORMATS,
  AppPage,
  AudiophileFormatId,
  LibraryTab,
  LoopMode,
  Track,
  UserPlaylist,
} from './types';
import {
  getAllTracksFromDB,
  saveTrackToDB,
  saveMetadataTrackToDB,
  deleteTrackFromDB,
  toggleFavoriteInDB,
  getAllPlaylists,
  createPlaylist,
  addTrackToPlaylist,
  deletePlaylist,
} from './services/storage';
import { convertBlobToMp3 } from './services/mp3Converter';
import { loadSavedYoutubeCookies, saveYoutubeCookies } from './services/youtubeCookies';
import { extractYouTubeId } from './services/mediaResolver';
import { playerEngine } from './services/playerService';
import { usePWAInstall } from './hooks/usePWAInstall';
import { useServiceWorkerUpdate } from './hooks/useServiceWorkerUpdate';
import { TrackCard } from './components/TrackCard';
import { PlaylistPickerModal } from './components/PlaylistPickerModal';
import { ScheduleModal } from './components/ScheduleModal';
import { useListenScheduleRunner } from './hooks/useListenScheduleRunner';
import { PendingPlay, resolvePlayTarget } from './services/scheduleService';
import { LastNotifiedListen, loadLastNotifiedListen, saveLastNotifiedListen } from './services/lastNotified';
import { resolveFreshListen } from './services/freshListenService';
import { NowPlayingBar } from './components/NowPlayingBar';
import { FullPlayerModal } from './components/FullPlayerModal';
import { DownloadDialog } from './components/DownloadDialog';
import { YouTubeBrowserModal } from './components/YouTubeBrowserModal';
import { LyricsModal } from './components/LyricsModal';
import { AndroidProjectModal } from './components/AndroidProjectModal';
import { InstallGuideModal } from './components/InstallGuideModal';
import { SettingsModal } from './components/SettingsModal';
import { resolveConverterApiBaseUrl } from './services/converterServerUrl';
import { Toast, ToastMessage } from './components/Toast';
import { GramophoneDiscLogo } from './components/GramophoneDiscLogo';
import { AppPageNav } from './components/AppPageNav';
import { HomeListenDashboard } from './components/HomeListenDashboard';
import { MorePage } from './components/MorePage';
import { ActivityLogModal } from './components/ActivityLogModal';
import { logActivity } from './services/activityLog';
import {
  apiUrl,
  checkConverterApiAvailable,
  downloadConvertJobResult,
  fetchWithTimeout,
  humanizeConverterError,
  readConverterError,
  startConvertJob,
  studioFormatWarning,
  waitForConvertJob,
} from './services/converterApi';
import {
  bitrateKbpsForFormat,
  extensionForFormat,
  formatFromMimeOrExt,
  mimeForFormat,
} from './utils/audioFormatLabel';
import {
  downloadYouTubeAudioOnDevice,
  isInsideApk,
  isOnDeviceDownloadAvailable,
  transcodeOnServer,
} from './services/onDeviceDownload';

export default function App() {
  const { isInstallable, install, isAndroid, isInstalled } = usePWAInstall();
  const { updateReady, reloadForUpdate } = useServiceWorkerUpdate();

  // Library state
  const [tracks, setTracks] = useState<Track[]>([]);
  const [selectedTab, setSelectedTab] = useState<LibraryTab>('ALL');
  const [playlists, setPlaylists] = useState<UserPlaylist[]>([]);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState<string | null>(null);
  const [showPlaylistPicker, setShowPlaylistPicker] = useState(false);
  const [playlistPickerTrackId, setPlaylistPickerTrackId] = useState<string | null>(null);
  const [libraryReady, setLibraryReady] = useState(false);
  const [activePage, setActivePage] = useState<AppPage>('home');
  const [lastNotified, setLastNotified] = useState<LastNotifiedListen | null>(() => loadLastNotifiedListen());
  const [searchQuery, setSearchQuery] = useState('');
  /** Music-first: YouTube video surface off by default; audio still plays. */
  const [showVideo, setShowVideo] = useState(() => {
    if (typeof window === 'undefined') return false;
    try {
      return localStorage.getItem('ogm_show_video') === '1';
    } catch {
      return false;
    }
  });

  // Inline Tape Deck Recorder state
  const [inlineUrl, setInlineUrl] = useState('');
  const [inlineFormat, setInlineFormat] = useState<AudiophileFormatId>('MP3');
  const [inlineMp3Bitrate, setInlineMp3Bitrate] = useState<number>(320);
  const [inlineSaveToDevice, setInlineSaveToDevice] = useState(true);
  const [inlineCookies, setInlineCookies] = useState('');
  const [showInlineCookies, setShowInlineCookies] = useState(false);
  const [inlinePreview, setInlinePreview] = useState<{
    valid: boolean;
    isYouTube: boolean;
    id: string;
    title: string;
    author: string;
    thumbnailUrl: string;
  } | null>(null);
  const [inlineValidationError, setInlineValidationError] = useState<string | null>(null);
  const [isValidatingInline, setIsValidatingInline] = useState(false);

  // Player state
  const [currentTrack, setCurrentTrack] = useState<Track | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [loopMode, setLoopMode] = useState<LoopMode>('OFF');
  const [isShuffle, setIsShuffle] = useState(false);
  const [playbackSpeed, setPlaybackSpeed] = useState(1.0);
  const [volume, setVolume] = useState(0.85);

  // Conversion & Download State
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadProgress, setDownloadProgress] = useState(0);
  const [downloadStatus, setDownloadStatus] = useState('');
  const [downloadError, setDownloadError] = useState<string | null>(null);
  const [converterApiOnline, setConverterApiOnline] = useState<boolean | null>(null);
  const [convertingTrackId, setConvertingTrackId] = useState<string | null>(null);
  const [convertingProgress, setConvertingProgress] = useState(0);

  // Modal Dialogs
  const [showDownloadDialog, setShowDownloadDialog] = useState(false);
  const [tunerQuery, setTunerQuery] = useState('');
  const [heroListenQuery, setHeroListenQuery] = useState('');
  const [showFullPlayer, setShowFullPlayer] = useState(false);
  const [showAndroidProject, setShowAndroidProject] = useState(false);
  const [showInstallGuide, setShowInstallGuide] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showActivityLog, setShowActivityLog] = useState(false);
  const swUpdateToastShown = useRef(false);
  const importingRef = useRef(false);
  const filePickerRef = useRef<HTMLInputElement>(null);
  const folderPickerRef = useRef<HTMLInputElement>(null);
  const [importProgress, setImportProgress] = useState<{ done: number; total: number; name: string } | null>(null);
  const supportsFolderPick =
    typeof document !== 'undefined' &&
    'webkitdirectory' in document.createElement('input') &&
    !/OpenGraceMusicAPK/.test(typeof navigator !== 'undefined' ? navigator.userAgent : '');
  const [selectedTrackForLyrics, setSelectedTrackForLyrics] = useState<Track | null>(null);
  const [prefilledUrl, setPrefilledUrl] = useState<string | null>(null);

  // Toast notifications
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const rememberNotified = (item: LastNotifiedListen) => {
    setLastNotified(saveLastNotifiedListen(item));
  };

  const addToast = (text: string, type: 'success' | 'error' | 'info' = 'info') => {
    const id = Date.now().toString(36) + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, text, type }]);
    const ttl = type === 'error' ? 10_000 : 4_000;
    setTimeout(() => {
      setToasts((prev) => {
        const toast = prev.find((t) => t.id === id);
        if (toast?.persist) return prev;
        return prev.filter((t) => t.id !== id);
      });
    }, ttl);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Subscribe to Offline-First Audio Engine
  useEffect(() => {
    const unsubscribe = playerEngine.subscribe({
      onPlayStateChange: (playing) => setIsPlaying(playing),
      onTimeUpdate: (cur, dur) => {
        setCurrentTime(cur);
        if (dur > 0) setDuration(dur);
      },
      onTrackEnded: () => {
        handleTrackEnded();
      },
      onNextRequested: () => {
        handleNextTrack();
      },
      onPrevRequested: () => {
        handlePrevTrack();
      },
      onError: (msg) => {
        addToast(msg, 'error');
      },
    });

    return () => unsubscribe();
  }, [tracks, currentTrack, loopMode, isShuffle]);

  const playScheduledTarget = async (pending: PendingPlay) => {
    const resolved = await resolvePlayTarget(pending, tracks, playlists);
    if (resolved.playlistId) setSelectedPlaylistId(resolved.playlistId);
    if (resolved.track) {
      setCurrentTrack(resolved.track);
      setCurrentTime(0);
      setDuration(resolved.track.duration || 0);
      await playerEngine.playTrack(resolved.track);
      rememberNotified({
        title: resolved.track.title,
        ytVideoId: resolved.track.ytVideoId,
        query: pending.freshQuery,
        scheduleName: pending.scheduleName || resolved.track.title,
        freshMode: pending.freshMode,
        playlistId: pending.playlistId,
        trackId: resolved.track.id,
        at: Date.now(),
      });
      addToast(`Playing ${pending.scheduleName || resolved.track.title}`, 'success');
      return;
    }
    if (resolved.useFresh && (pending.freshQuery || '').trim()) {
      const query = pending.freshQuery!.trim();
      addToast(`Finding newest match for “${query}”…`, 'info');
      try {
        const fresh = await resolveFreshListen(query, pending.freshMode || 'latest');
        if (!fresh) {
          addToast(
            `No fresh match for “${query}”. Nothing played — search was empty or unavailable. We will not play a stale cassette or a different song.`,
            'error'
          );
          return;
        }
        const saved = await saveMetadataTrackToDB(fresh);
        setTracks((prev) => [saved, ...prev.filter((t) => t.id !== saved.id)]);
        setCurrentTrack(saved);
        setCurrentTime(0);
        setDuration(saved.duration || 0);
        await playerEngine.playTrack(saved);
        rememberNotified({
          title: saved.title,
          ytVideoId: saved.ytVideoId,
          query,
          scheduleName: pending.scheduleName || saved.title,
          freshMode: pending.freshMode || 'latest',
          playlistId: pending.playlistId,
          trackId: saved.id,
          at: Date.now(),
        });
        addToast(`Playing newest match: ${saved.title}`, 'success');
      } catch {
        addToast(
          `Could not search for “${query}”. Nothing played. Try again while the app is online.`,
          'error'
        );
      }
      return;
    }
    if (resolved.missing) {
      addToast(
        'Nothing to play — add a mix, a tape, or a fresh search query on the reminder.',
        'error'
      );
      return;
    }
    if (resolved.emptyMix) {
      addToast(
        'That mix is empty — add a tape, or set a fresh query on the reminder so we can find today’s match.',
        'error'
      );
    }
  };

  useListenScheduleRunner({
    ready: libraryReady,
    onPlay: (pending) => {
      setActivePage('home');
      void playScheduledTarget(pending);
    },
    onNotified: (item) => setLastNotified(item),
    onInAppReminder: (schedule, pending) => {
      const id = `sched-${schedule.id}-${Date.now().toString(36)}`;
      setToasts((prev) => [
        ...prev,
        {
          id,
          type: 'info',
          text: `${schedule.name} — tap to play`,
          actionLabel: 'Play',
          persist: true,
          onAction: () => {
            void playScheduledTarget(pending);
            setToasts((p) => p.filter((t) => t.id !== id));
          },
        },
      ]);
    },
  });

  useEffect(() => {
    setInlineCookies(loadSavedYoutubeCookies());
    void (async () => {
      await loadLibrary();
      setPlaylists(await getAllPlaylists());
      setLibraryReady(true);
    })();
  }, []);

  useEffect(() => {
    saveYoutubeCookies(inlineCookies);
  }, [inlineCookies]);

  useEffect(() => {
    playerEngine.setShowVideo(showVideo);
    try {
      localStorage.setItem('ogm_show_video', showVideo ? '1' : '0');
    } catch {
      // ignore quota / private mode
    }
  }, [showVideo]);

  const refreshConverterHealth = () => {
    checkConverterApiAvailable().then((ok) => setConverterApiOnline(ok));
  };

  useEffect(() => {
    let cancelled = false;
    checkConverterApiAvailable().then((ok) => {
      if (!cancelled) setConverterApiOnline(ok);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (!updateReady || swUpdateToastShown.current) return;
    swUpdateToastShown.current = true;
    const id = `sw-update-${Date.now().toString(36)}`;
    setToasts((prev) => [
      ...prev,
      {
        id,
        type: 'info',
        text: 'Update available — reload for the latest Open Grace Music UI.',
        actionLabel: 'Reload',
        onAction: () => reloadForUpdate(),
        persist: true,
      },
    ]);
  }, [updateReady, reloadForUpdate]);

  const loadLibrary = async () => {
    try {
      const loaded = await getAllTracksFromDB();
      setTracks(loaded);
    } catch {
      addToast('Could not load tracks.', 'error');
    }
  };

  // Validate Inline Converter URL via /api/validate-url
  const validateInlineUrl = async (rawUrl: string) => {
    const trimmed = rawUrl.trim();
    if (!trimmed) {
      setInlinePreview(null);
      setInlineValidationError(null);
      return;
    }

    setIsValidatingInline(true);
    setInlineValidationError(null);
    try {
      const res = await fetchWithTimeout(apiUrl(`/api/validate-url?url=${encodeURIComponent(trimmed)}`), {
        timeoutMs: 20_000,
      });
      const data = await res.json();
      if (res.ok && data.valid) {
        setInlinePreview({
          valid: true,
          isYouTube: !!data.isYouTube,
          id: data.videoId || data.id,
          title: data.title || 'Audio Stream',
          author: data.author || 'Open Grace Music',
          thumbnailUrl: data.thumbnailUrl || '',
        });
      } else {
        setInlinePreview(null);
        setInlineValidationError(data.error || 'Enter a valid YouTube or audio URL.');
      }
    } catch (err: unknown) {
      const ytId = extractYouTubeId(trimmed);
      const { message, code } = humanizeConverterError(err);
      if (ytId && code === 'NETWORK') {
        setInlinePreview({
          valid: true,
          isYouTube: true,
          id: ytId,
          title: `YouTube Track (${ytId})`,
          author: 'YouTube Music',
          thumbnailUrl: `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`,
        });
        setInlineValidationError(message);
      } else if (ytId) {
        setInlinePreview({
          valid: true,
          isYouTube: true,
          id: ytId,
          title: `YouTube Track (${ytId})`,
          author: 'YouTube Music',
          thumbnailUrl: `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`,
        });
      } else {
        setInlinePreview(null);
        setInlineValidationError(message);
      }
    } finally {
      setIsValidatingInline(false);
    }
  };

  const handleInlinePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setInlineUrl(text);
        validateInlineUrl(text);
      }
    } catch {
      addToast('Long-press input to paste URL.', 'info');
    }
  };

  // Filtered tracks
  const filteredTracks = useMemo(() => {
    let result = [...tracks];

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      result = result.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          t.artist.toLowerCase().includes(q) ||
          t.album.toLowerCase().includes(q) ||
          t.format.toLowerCase().includes(q)
      );
    }

    if (selectedPlaylistId) {
      const list = playlists.find((p) => p.id === selectedPlaylistId);
      if (list) {
        const byId = new Map(result.map((t) => [t.id, t]));
        return list.trackIds.map((id) => byId.get(id)).filter((t): t is Track => Boolean(t));
      }
    }

    switch (selectedTab) {
      case 'LOSSLESS':
        return result.filter((t) =>
          ['FLAC', 'ALAC', 'DSD', 'WAV'].includes(t.format.toUpperCase())
        );
      case 'DOWNLOADS':
        return result.filter((t) => t.source === 'YOUTUBE' || t.source === 'DIRECT_URL');
      case 'DEVICE_MUSIC':
        return result.filter((t) => t.source === 'LOCAL_IMPORT' || t.source === 'SAMPLE_AUDIO');
      case 'MP3':
        return result.filter(
          (t) => t.format.toUpperCase() === 'MP3' || t.mimeType.includes('mpeg')
        );
      case 'FAVORITES':
        return result.filter((t) => t.isFavorite);
      case 'ALL':
      default:
        return result;
    }
  }, [tracks, searchQuery, selectedTab, selectedPlaylistId, playlists]);

  // Playback Handlers
  const playTrack = async (track: Track) => {
    if (currentTrack?.id === track.id) {
      playerEngine.togglePlayPause();
      return;
    }

    setCurrentTrack(track);
    setCurrentTime(0);
    setDuration(track.duration || 0);
    await playerEngine.playTrack(track);
  };

  const togglePlayPause = () => {
    if (!currentTrack) {
      if (filteredTracks.length > 0) {
        playTrack(filteredTracks[0]);
      } else {
        handleLoadSampleTracks();
      }
      return;
    }
    playerEngine.togglePlayPause();
  };

  const queueTracks = filteredTracks.length ? filteredTracks : tracks;

  const handleNextTrack = () => {
    if (!queueTracks.length) return;
    const currentIdx = queueTracks.findIndex((t) => t.id === currentTrack?.id);

    if (isShuffle) {
      const randomIdx = Math.floor(Math.random() * queueTracks.length);
      playTrack(queueTracks[randomIdx]);
      return;
    }

    const nextIdx = (currentIdx + 1) % queueTracks.length;
    playTrack(queueTracks[nextIdx]);
  };

  const handlePrevTrack = () => {
    if (!queueTracks.length) return;
    if (currentTime > 3) {
      playerEngine.seekTo(0);
      return;
    }
    const currentIdx = queueTracks.findIndex((t) => t.id === currentTrack?.id);
    const prevIdx = (currentIdx - 1 + queueTracks.length) % queueTracks.length;
    playTrack(queueTracks[prevIdx]);
  };

  const handleSeek = (time: number) => {
    setCurrentTime(time);
    playerEngine.seekTo(time);
  };

  const handleVolumeChange = (vol: number) => {
    setVolume(vol);
    playerEngine.setVolume(vol);
  };

  const handleSpeedChange = (spd: number) => {
    setPlaybackSpeed(spd);
    playerEngine.setPlaybackRate(spd);
  };

  const cycleLoopMode = () => {
    const next: LoopMode = loopMode === 'OFF' ? 'ALL' : loopMode === 'ALL' ? 'ONE' : 'OFF';
    setLoopMode(next);
    addToast(`Repeat: ${next}`, 'info');
  };

  const openPlaylistPicker = (trackId: string | null) => {
    setPlaylistPickerTrackId(trackId);
    setShowPlaylistPicker(true);
  };

  const closePlaylistPicker = () => {
    setShowPlaylistPicker(false);
    setPlaylistPickerTrackId(null);
  };

  const handleCreateMix = async (name: string) => {
    const pl = await createPlaylist(name);
    if (playlistPickerTrackId) {
      await addTrackToPlaylist(pl.id, playlistPickerTrackId);
      setPlaylists(await getAllPlaylists());
      addToast(`Added to ${pl.name}`, 'success');
      closePlaylistPicker();
      return;
    }
    setPlaylists(await getAllPlaylists());
    setSelectedPlaylistId(pl.id);
    addToast(`${pl.name} mix is ready`, 'success');
    closePlaylistPicker();
  };

  const handlePickMix = async (playlistId: string) => {
    const pl = playlists.find((p) => p.id === playlistId);
    if (playlistPickerTrackId) {
      await addTrackToPlaylist(playlistId, playlistPickerTrackId);
      setPlaylists(await getAllPlaylists());
      addToast(pl ? `Added to ${pl.name}` : 'Added to mix', 'success');
      closePlaylistPicker();
      return;
    }
    setSelectedPlaylistId(playlistId);
    closePlaylistPicker();
  };

  const handleDeleteMix = async (playlistId: string, event?: React.MouseEvent) => {
    event?.stopPropagation();
    const pl = playlists.find((p) => p.id === playlistId);
    await deletePlaylist(playlistId);
    setPlaylists(await getAllPlaylists());
    if (selectedPlaylistId === playlistId) setSelectedPlaylistId(null);
    addToast(pl ? `Removed ${pl.name}` : 'Mix removed', 'info');
  };

  const handleTrackEnded = () => {
    if (loopMode === 'ONE') {
      playerEngine.seekTo(0);
      if (currentTrack) playerEngine.playTrack(currentTrack);
    } else if (loopMode === 'ALL' || isShuffle) {
      handleNextTrack();
    } else {
      setIsPlaying(false);
    }
  };

  const triggerBrowserDownload = (blob: Blob, title: string, ext: string) => {
    const safeTitle = title.replace(/[^a-zA-Z0-9._ -]/g, '').trim() || 'OpenGraceMusic_Track';
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = blobUrl;
    a.download = `${safeTitle}.${ext.toLowerCase()}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(blobUrl), 5000);
  };

  // Import Local Audio Files
  const AUDIO_EXT = /\.(mp3|flac|m4a|alac|aac|wav|ogg|oga|opus|webm|mp4|dsf|dff|wma|aif|aiff|amr|mka)$/i;
  const isAudioFile = (f: File) => f.type.startsWith('audio/') || AUDIO_EXT.test(f.name);

  const importFiles = async (all: File[]) => {
    if (importingRef.current) {
      addToast('An import is already running…', 'info');
      return;
    }
    if (!all.length) {
      addToast('No files selected.', 'info');
      return;
    }
    const audio = all.filter(isAudioFile);
    const skipped = all.length - audio.length;
    if (!audio.length) {
      addToast(`No audio files found (${all.length} skipped).`, 'error');
      return;
    }
    importingRef.current = true;
    const seen = new Set(tracks.map((t) => `${t.title}|${t.sizeBytes}`));
    let saved = 0;
    let failed = 0;
    let dupes = 0;
    addToast(`Importing ${audio.length} audio file${audio.length === 1 ? '' : 's'}…`, 'info');

    for (let i = 0; i < audio.length; i++) {
      const file = audio[i];
      setImportProgress({ done: i, total: audio.length, name: file.name });
      await new Promise((r) => setTimeout(r, 0));
      const ext = file.name.split('.').pop()?.toUpperCase() || 'MP3';
      const cleanTitle = file.name.replace(/\.[^.]+$/, '').replace(/[_-]+/g, ' ');
      try {
        if (seen.has(`${cleanTitle}|${file.size}`)) {
          dupes++;
          continue;
        }
        const durationSec = await new Promise<number>((resolve) => {
          const tempUrl = URL.createObjectURL(file);
          const probe = new Audio();
          const done = (d: number) => {
            clearTimeout(timer);
            URL.revokeObjectURL(tempUrl);
            resolve(Number.isFinite(d) ? d : 0);
          };
          const timer = setTimeout(() => done(0), 4000);
          probe.preload = 'metadata';
          probe.onloadedmetadata = () => done(probe.duration || 0);
          probe.onerror = () => done(0);
          probe.src = tempUrl;
        });
        const isLossless = ['FLAC', 'ALAC', 'DSD', 'DSF', 'DFF', 'WAV', 'AIFF', 'AIF'].includes(ext);
        const newTrack: Track = {
          id: `local_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          title: cleanTitle,
          artist: 'Device Master',
          album: 'Cassette Archive',
          duration: durationSec,
          sizeBytes: file.size,
          format: ext,
          mimeType: file.type || (ext === 'FLAC' ? 'audio/flac' : 'audio/mpeg'),
          source: 'LOCAL_IMPORT',
          storageStatus: 'PERSISTENT',
          addedAt: Date.now(),
          bitrateKbps: isLossless ? 2304 : 320,
          sampleRateHz: isLossless ? 96000 : 48000,
          bitDepth: isLossless ? '24-bit' : '16-bit',
          isFavorite: false,
        };
        const savedTrack = await saveTrackToDB(newTrack, file);
        seen.add(`${cleanTitle}|${file.size}`);
        setTracks((prev) => [savedTrack, ...prev]);
        saved++;
        logActivity({
          action: 'import',
          label: `Imported "${cleanTitle}"`,
          result: 'saved',
          format: ext,
          sizeBytes: file.size,
          detail: 'Device file stored offline in Library',
          source: file.name,
        });
      } catch (err: any) {
        failed++;
        logActivity({
          action: 'import',
          label: 'Import failed',
          result: 'failed',
          detail: err?.message || 'Could not import file',
          source: file.name,
        });
      }
    }
    setImportProgress(null);
    importingRef.current = false;
    const parts = [`${saved} imported`];
    if (dupes) parts.push(`${dupes} duplicate${dupes === 1 ? '' : 's'} skipped`);
    if (skipped) parts.push(`${skipped} non-audio skipped`);
    if (failed) parts.push(`${failed} failed`);
    addToast(parts.join(' · '), failed && !saved ? 'error' : 'success');
  };

  const handleLocalFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    e.target.value = '';
    await importFiles(files);
  };

  /**
   * APK-only: resolve + download the exact video's audio on the phone (phone IP, not the
   * bot-checked server). Saves a real offline blob with its TRUE container. Returns null on
   * success, or the real failure reason so the caller can fall back to the server route.
   */
  const recordOnDevice = async (
    ytId: string,
    trimmedUrl: string,
    format: AudiophileFormatId,
    bitrateKbps: number,
    saveToDeviceFolder: boolean,
    customTitle?: string,
    customArtist?: string
  ): Promise<{ ok: true } | { ok: false; reason: string }> => {
    const label = 'Record YouTube';
    let lastLoggedStage = '';
    try {
      setDownloadProgress(0.04);
      setDownloadStatus('ON-DEVICE: asking YouTube from this phone…');
      logActivity({
        action: 'record',
        label,
        result: 'started',
        format,
        detail: `route=on-device · downloading ${ytId} on the phone (not the server)`,
        source: trimmedUrl,
      });

      const { blob: rawBlob, info } = await downloadYouTubeAudioOnDevice(ytId, format, (p) => {
        setDownloadProgress(Math.max(0.04, Math.min(0.85, (p.percent || 0) / 100 * 0.85)));
        setDownloadStatus(`ON-DEVICE: ${p.message}`);
        if (p.stage && p.stage !== lastLoggedStage) {
          lastLoggedStage = p.stage;
          logActivity({
            action: 'record',
            label,
            result: 'progress',
            format,
            detail: `route=on-device · ${p.stage} · ${p.message}`,
            source: trimmedUrl,
          });
        }
      });

      const title = customTitle || info.title || `YouTube ${ytId}`;
      const artist = customArtist || info.author || 'Open Grace Music';
      let finalBlob: Blob = rawBlob;
      let finalFormat: string = info.container; // real container unless transcoded below
      let finalMime = info.mime;
      let finalBitrate = info.bitrateKbps;
      let note = '';

      const wantsTranscode = format === 'MP3' || format === 'FLAC' || format === 'ALAC' || format === 'WAV';
      if (format === 'DSD') {
        note = ' · DSD is not produced on-device; saved the real ' + info.container;
      } else if (wantsTranscode) {
        setDownloadProgress(0.88);
        setDownloadStatus(`Converting downloaded ${info.container} → ${format}…`);
        try {
          if (format === 'MP3') {
            finalBlob = await convertBlobToMp3(rawBlob, bitrateKbps, (pr) =>
              setDownloadProgress(0.88 + pr * 0.08)
            );
            finalMime = 'audio/mpeg';
            finalBitrate = bitrateKbpsForFormat('MP3', bitrateKbps);
            note = ` · converted on-device from lossy ${info.codec}`;
          } else {
            finalBlob = await transcodeOnServer(rawBlob, format, apiUrl);
            finalMime = mimeForFormat(format);
            finalBitrate = bitrateKbpsForFormat(format, bitrateKbps);
            note = ` · transcoded by server from the already-downloaded lossy ${info.codec} (no quality gained)`;
          }
          finalFormat = format;
        } catch (convErr) {
          finalBlob = rawBlob;
          finalFormat = info.container;
          finalMime = info.mime;
          finalBitrate = info.bitrateKbps;
          const why = convErr instanceof Error ? convErr.message : 'conversion failed';
          note = ` · could not convert to ${format} (${why}); saved the real ${info.container} instead`;
        }
      }

      const ext = extensionForFormat(finalFormat);
      const fmtOpt = AUDIOPHILE_FORMATS.find((f) => f.id === finalFormat);
      const lossyNote =
        finalFormat === 'FLAC' || finalFormat === 'ALAC' || finalFormat === 'WAV'
          ? ` (YouTube source is lossy ${info.codec})`
          : '';
      const track: Track = {
        id: `yt_${ytId}_${finalFormat.toLowerCase()}`,
        title,
        artist,
        album: `Open Grace · ${finalFormat}${lossyNote || (finalFormat === info.container ? ` ${info.codec} (as downloaded)` : '')}`,
        duration: info.durationSec || 0,
        sizeBytes: finalBlob.size,
        format: finalFormat,
        mimeType: finalMime,
        source: 'YOUTUBE',
        storageStatus: 'PERSISTENT',
        addedAt: Date.now(),
        thumbnailUrl: `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`,
        bitrateKbps: finalBitrate,
        sampleRateHz: fmtOpt?.sampleRateHz,
        bitDepth: fmtOpt?.bitDepth,
        isFavorite: false,
        originalUrl: trimmedUrl,
        ytVideoId: ytId,
      };
      if (!track.duration) {
        track.duration = await new Promise<number>((resolve) => {
          const u = URL.createObjectURL(finalBlob);
          const probe = new Audio();
          probe.onloadedmetadata = () => {
            URL.revokeObjectURL(u);
            resolve(probe.duration || 0);
          };
          probe.onerror = () => {
            URL.revokeObjectURL(u);
            resolve(0);
          };
          probe.src = u;
        });
      }

      setDownloadProgress(0.97);
      const saved = await saveTrackToDB(track, finalBlob);
      setTracks((prev) => [saved, ...prev.filter((t) => t.id !== saved.id)]);
      if (saveToDeviceFolder) triggerBrowserDownload(finalBlob, title, ext);

      setShowDownloadDialog(false);
      setActivePage('library');
      setInlineUrl('');
      setInlinePreview(null);

      logActivity({
        action: 'record',
        label: `Saved "${title}"`,
        result: 'saved',
        format: finalFormat,
        sizeBytes: finalBlob.size,
        detail: `route=on-device (${info.client}) · real .${ext} stored in Library · plays offline${note}`,
        source: trimmedUrl,
      });
      addToast(`♪ Recorded "${title}" on this phone (${finalFormat}${note})`, 'success');
      playTrack(saved);
      return { ok: true };
    } catch (err) {
      const reason = err instanceof Error ? err.message : 'On-device download failed';
      logActivity({
        action: 'record',
        label,
        result: 'failed',
        format,
        detail: `route=on-device · ${reason}`,
        source: trimmedUrl,
      });
      return { ok: false, reason };
    }
  };

  // Real Audiophile Lossless & Hi-Res Download & Conversion Handler
  const handleStartDownload = async (
    url: string,
    format: AudiophileFormatId = 'MP3',
    bitrateKbps: number = 320,
    saveToDeviceFolder: boolean = true,
    cookies?: string,
    customTitle?: string,
    customArtist?: string
  ) => {
    const trimmedUrl = url.trim();
    if (!trimmedUrl) {
      addToast('Enter a YouTube or audio URL.', 'error');
      return;
    }

    const formatObj = AUDIOPHILE_FORMATS.find((f) => f.id === format) || AUDIOPHILE_FORMATS[0];

    setIsDownloading(true);
    setDownloadError(null);
    setDownloadProgress(0.08);
    setDownloadStatus(`Validating · preparing ${format} (${formatObj.badge})...`);

    const ytId = extractYouTubeId(trimmedUrl);

    logActivity({
      action: 'record',
      label: ytId ? 'Record YouTube' : 'Record URL',
      result: 'started',
      format,
      detail: `Requested an offline ${format} file`,
      source: trimmedUrl,
    });

    let loggedStage = '';

    const insideApk = isInsideApk();
    let onDeviceFailure: string | null = null;
    if (ytId && isOnDeviceDownloadAvailable()) {
      const r = await recordOnDevice(
        ytId,
        trimmedUrl,
        format,
        bitrateKbps,
        saveToDeviceFolder,
        customTitle,
        customArtist
      );
      if (r.ok) {
        setIsDownloading(false);
        setDownloadProgress(0);
        setDownloadStatus('');
        return;
      }
      onDeviceFailure = r.reason;
      setDownloadProgress(0.08);
      setDownloadStatus('On-device failed — trying the server route…');
      logActivity({
        action: 'record',
        label: 'Record YouTube',
        result: 'progress',
        format,
        detail: `route=server · falling back after on-device failure`,
        source: trimmedUrl,
      });
    } else if (ytId && insideApk) {
      onDeviceFailure = 'this installed APK is too old to download on the phone (reinstall the latest APK)';
    }

    try {
      const { jobId } = await startConvertJob({
        url: trimmedUrl,
        format,
        bitrate: format === 'MP3' ? bitrateKbps : bitrateKbps,
        cookies: (cookies || inlineCookies || loadSavedYoutubeCookies()).trim() || undefined,
        title: customTitle,
        artist: customArtist,
      });

      await waitForConvertJob(
        jobId,
        (status) => {
          setDownloadProgress(Math.max(0.05, Math.min(0.98, status.percent / 100)));
          const stageLabel =
            status.stage === 'validate'
              ? 'VALIDATING'
              : status.stage === 'extract'
                ? 'EXTRACTING'
                : status.stage === 'ffmpeg'
                  ? 'FFMPEG MASTERING'
                  : status.stage === 'save'
                    ? 'SAVING'
                    : 'PROCESSING';
          setDownloadStatus(`${stageLabel}: ${status.message}`);
          if (status.stage && status.stage !== loggedStage && status.stage !== 'done') {
            loggedStage = status.stage;
            logActivity({
              action: 'record',
              label: ytId ? 'Record YouTube' : 'Record URL',
              result: 'progress',
              format,
              detail: `${stageLabel} · ${status.message}`,
              source: trimmedUrl,
            });
          }
        },
        180_000
      );

      setDownloadProgress(0.92);
      setDownloadStatus('Downloading mastered file...');

      const response = await downloadConvertJobResult(jobId);

      if (!response.ok) {
        throw await readConverterError(response);
      }

      const responseType = response.headers.get('content-type') || '';
      if (responseType.includes('application/json')) {
        throw await readConverterError(response);
      }

      setDownloadProgress(0.8);
      setDownloadStatus(`MASTERING ${format} REEL...`);

      const headerTitle = response.headers.get('X-Audio-Title')
        ? decodeURIComponent(response.headers.get('X-Audio-Title')!)
        : customTitle || `Audiophile Track`;
      const headerArtist = response.headers.get('X-Audio-Artist')
        ? decodeURIComponent(response.headers.get('X-Audio-Artist')!)
        : customArtist || 'Open Grace Music';
      const headerDuration = parseInt(response.headers.get('X-Audio-Duration') || '0', 10);
      const contentType = (response.headers.get('Content-Type') || '').split(';')[0].trim();
      const headerExtRaw = response.headers.get('X-Audio-Extension') || '';
      const headerFormatRaw = (response.headers.get('X-Audio-Format') || '').toUpperCase();
      const probedFromMime = formatFromMimeOrExt(contentType, headerExtRaw);
      // Prefer server-probed format; never keep a requested FLAC label if the body is MPEG.
      let headerFormat = (headerFormatRaw || probedFromMime || format) as AudiophileFormatId;
      if (probedFromMime && headerFormatRaw && probedFromMime !== headerFormatRaw) {
        headerFormat = probedFromMime;
      }
      const resolvedFormatObj =
        AUDIOPHILE_FORMATS.find((f) => f.id === headerFormat) || formatObj;
      const headerExt =
        headerExtRaw ||
        resolvedFormatObj.extension ||
        extensionForFormat(headerFormat);
      const headerSampleRate = parseInt(
        response.headers.get('X-Audio-Sample-Rate') || String(resolvedFormatObj.sampleRateHz),
        10
      );
      const headerBitDepth = response.headers.get('X-Audio-Bit-Depth') || resolvedFormatObj.bitDepth;
      const headerThumb = response.headers.get('X-Audio-Thumbnail')
        ? decodeURIComponent(response.headers.get('X-Audio-Thumbnail')!)
        : ytId
        ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`
        : undefined;

      const audioBlob = await response.blob();
      if (!audioBlob || audioBlob.size < 20000) {
        throw new Error('Audio stream was empty.');
      }

      // If the blob MIME disagrees with a lossless claim, trust the blob — never show FLAC for MPEG.
      const blobMime = (audioBlob.type || contentType || '').split(';')[0].trim();
      const blobFormat = formatFromMimeOrExt(blobMime, headerExt);
      if (blobFormat && blobFormat !== headerFormat) {
        if (headerFormat === 'FLAC' || headerFormat === 'ALAC' || headerFormat === 'WAV' || headerFormat === 'DSD') {
          if (blobFormat === 'MP3') {
            headerFormat = 'MP3';
          }
        }
      }
      if (
        (format === 'FLAC' || format === 'ALAC' || format === 'WAV' || format === 'DSD') &&
        headerFormat === 'MP3'
      ) {
        throw new Error(
          `Asked for ${format} but the converter returned MP3. Nothing was saved as ${format}.`
        );
      }

      const persistFormatObj =
        AUDIOPHILE_FORMATS.find((f) => f.id === headerFormat) || resolvedFormatObj;
      const persistMime =
        contentType ||
        blobMime ||
        persistFormatObj.mimeType ||
        mimeForFormat(headerFormat);
      const persistBitrate = bitrateKbpsForFormat(headerFormat, bitrateKbps);

      let finalDuration = headerDuration;
      if (!finalDuration || finalDuration <= 0) {
        finalDuration = await new Promise<number>((resolve) => {
          const tempUrl = URL.createObjectURL(audioBlob);
          const probe = new Audio();
          probe.onloadedmetadata = () => {
            const d = probe.duration || 210;
            URL.revokeObjectURL(tempUrl);
            resolve(d);
          };
          probe.onerror = () => {
            URL.revokeObjectURL(tempUrl);
            resolve(210);
          };
          probe.src = tempUrl;
        });
      }

      setDownloadProgress(0.95);

      const newTrack: Track = {
        id: ytId ? `yt_${ytId}_${headerFormat.toLowerCase()}` : `url_${Date.now()}`,
        title: headerTitle,
        artist: headerArtist,
        album:
          ytId && (headerFormat === 'FLAC' || headerFormat === 'ALAC' || headerFormat === 'WAV')
            ? `Open Grace · ${headerFormat} (YouTube source is lossy AAC/Opus)`
            : `Open Grace · ${headerFormat}`,
        duration: finalDuration,
        sizeBytes: audioBlob.size,
        format: headerFormat,
        mimeType: persistMime,
        source: ytId ? 'YOUTUBE' : 'DIRECT_URL',
        storageStatus: 'PERSISTENT',
        addedAt: Date.now(),
        thumbnailUrl: headerThumb,
        bitrateKbps: persistBitrate,
        sampleRateHz: headerSampleRate,
        bitDepth: headerBitDepth,
        isFavorite: false,
        originalUrl: trimmedUrl,
        ytVideoId: ytId || undefined,
      };

      const saved = await saveTrackToDB(newTrack, audioBlob);
      setTracks((prev) => [saved, ...prev.filter((t) => t.id !== saved.id)]);

      if (saveToDeviceFolder) {
        triggerBrowserDownload(
          audioBlob,
          headerTitle,
          extensionForFormat(headerFormat) || headerExt
        );
      }

      setShowDownloadDialog(false);
      setActivePage('library');
      setInlineUrl('');
      setInlinePreview(null);

      const honesty =
        ytId && (headerFormat === 'FLAC' || headerFormat === 'ALAC' || headerFormat === 'WAV')
          ? ` · real .${extensionForFormat(headerFormat)} from lossy YouTube source`
          : '';
      logActivity({
        action: 'record',
        label: `Saved "${headerTitle}"`,
        result: 'saved',
        format: headerFormat,
        sizeBytes: audioBlob.size,
        detail: `Offline .${extensionForFormat(headerFormat)} file stored in Library · plays with internet off`,
        source: trimmedUrl,
      });
      addToast(`♪ Recorded "${headerTitle}" (${headerFormat}${honesty})`, 'success');
      playTrack(saved);
    } catch (err: unknown) {
      const { message, code } = humanizeConverterError(err);
      // Honest failure: we NEVER silently save a live-stream tape and call it a download.
      // A genuine offline tape must carry real audio bytes. If the server could not produce
      // them (YouTube login/bot-check on a free host, extraction/timeout), say so clearly and
      // offer the real paths to an offline file. Live listening stays a separate, explicit choice.
      const serverBlocked =
        code === 'YOUTUBE_BOT_CHECK' || code === 'EXTRACTION_FAILED' || code === 'TIMEOUT';
      let display: string;
      if (ytId && insideApk) {
        display =
          `Couldn’t record this video. On this phone: ${onDeviceFailure ?? 'not attempted'}. ` +
          `On the server: ${message}. Nothing was saved as ${format}. ` +
          `Try again (check your connection or switch Wi‑Fi/mobile data), paste youtube.com cookies via the key icon ` +
          `so the server can try, or import an audio file. To only listen live (not an offline file), ` +
          `open the YouTube Tuner and tap Listen.`;
      } else if (ytId && serverBlocked) {
        display =
          `Couldn’t download this on the server (${message}) — nothing was saved as ${format}. ` +
          `Paste youtube.com cookies via the key icon and retry, install the Android APK (it downloads on your phone), ` +
          `or import an audio file. To only listen live (streams when online, not an offline file), ` +
          `open the YouTube Tuner and tap Listen.`;
      } else {
        display = message;
      }
      logActivity({
        action: 'record',
        label: ytId ? 'Record YouTube' : 'Record URL',
        result: 'failed',
        format,
        detail:
          ytId && serverBlocked
            ? `route=server · not downloaded (${message})${onDeviceFailure ? ` · on-device also failed: ${onDeviceFailure}` : ''}. Could still be played online-only via the Tuner.`
            : message,
        source: trimmedUrl,
      });
      setDownloadError(display);
      addToast(`Recorder error: ${display}`, 'error');
    } finally {
      setIsDownloading(false);
      setDownloadProgress(0);
      setDownloadStatus('');
    }
  };

  // Convert an existing track to MP3
  const handleConvertToMp3 = async (track: Track) => {
    setConvertingTrackId(track.id);
    setConvertingProgress(0.1);

    logActivity({
      action: 'convert',
      label: `Convert "${track.title}" → MP3`,
      result: 'started',
      format: 'MP3',
      detail: `Re-encoding ${track.format} to MP3 320K offline`,
    });

    try {
      let sourceBlob = track.blob;
      if (!sourceBlob && track.audioUrl) {
        const res = await fetch(track.audioUrl);
        if (res.ok) sourceBlob = await res.blob();
      }
      if (!sourceBlob) {
        throw new Error('Source audio not found.');
      }

      const mp3Blob = await convertBlobToMp3(sourceBlob, 320, (prog) => {
        setConvertingProgress(prog);
      });

      const updatedTrack: Track = {
        ...track,
        format: 'MP3',
        mimeType: 'audio/mpeg',
        sizeBytes: mp3Blob.size,
        bitrateKbps: 320,
      };

      const saved = await saveTrackToDB(updatedTrack, mp3Blob);
      setTracks((prev) => prev.map((t) => (t.id === track.id ? saved : t)));
      logActivity({
        action: 'convert',
        label: `Dubbed "${track.title}" to MP3`,
        result: 'saved',
        format: 'MP3',
        sizeBytes: mp3Blob.size,
        detail: 'Offline MP3 320K stored in Library',
      });
      addToast(`♪ Dubbed "${track.title}" to MP3 320K`, 'success');
    } catch (err: any) {
      logActivity({
        action: 'convert',
        label: `Convert "${track.title}" → MP3 failed`,
        result: 'failed',
        format: 'MP3',
        detail: err?.message || 'Conversion failed',
      });
      addToast(`Conversion failed: ${err.message}`, 'error');
    } finally {
      setConvertingTrackId(null);
      setConvertingProgress(0);
    }
  };

  // Delete Track
  const handleDeleteTrack = async (track: Track) => {
    try {
      await deleteTrackFromDB(track.id);
      setTracks((prev) => prev.filter((t) => t.id !== track.id));
      setPlaylists(await getAllPlaylists());
      if (currentTrack?.id === track.id) {
        playerEngine.togglePlayPause();
        setCurrentTrack(null);
        setIsPlaying(false);
      }
      addToast(`Ejected "${track.title}"`, 'info');
    } catch {
      addToast(`Could not remove "${track.title}"`, 'error');
    }
  };

  // Toggle Favorite
  const handleToggleFavorite = async (track: Track) => {
    const nextFav = await toggleFavoriteInDB(track.id);
    setTracks((prev) =>
      prev.map((t) => (t.id === track.id ? { ...t, isFavorite: nextFav } : t))
    );
  };

  // Export Track
  const handleExportTrack = (track: Track) => {
    if (track.blob) {
      const extMap: Record<string, string> = {
        FLAC: 'flac',
        ALAC: 'm4a',
        DSD: 'wav',
        WAV: 'wav',
        MP3: 'mp3',
        M4A: 'm4a',
        OPUS: 'webm',
      };
      const ext = extMap[track.format.toUpperCase()] || track.format.toLowerCase() || 'flac';
      triggerBrowserDownload(track.blob, track.title, ext);
      addToast(`♪ Saved "${track.title}.${ext}"`, 'success');
      return;
    }

    if (track.audioUrl) {
      const ext = track.format.toLowerCase() || 'flac';
      const a = document.createElement('a');
      a.href = track.audioUrl;
      a.download = `${track.title}.${ext}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      addToast(`♪ Saved "${track.title}.${ext}"`, 'success');
      return;
    }

    if (track.ytVideoId && track.format === 'YouTube') {
      addToast(
        'This is a live YouTube tape (online-only) — there is no offline file to save. Record it as MP3/FLAC to get an offline copy.',
        'error'
      );
      return;
    }
    addToast('No offline audio file found for this tape.', 'error');
  };

  // Load Built-in Studio Acoustic Tracks
  const handleLoadSampleTracks = async () => {
    const samples = [
      {
        title: 'Grace Morning Chords (Studio Session)',
        artist: 'Open Grace Ensemble',
        album: 'Acoustic Sanctuary',
        url: '/assets/WhatsApp_Audio_2026-10-23_at_2.57.53_AM_3d0a1356.mpeg',
      },
      {
        title: 'Quiet Harbor Melody (Master Acoustic)',
        artist: 'Open Grace Studio',
        album: 'Nightfall Resonance',
        url: '/assets/WhatsApp_Audio_2026-10-23_at_2.57.57_AM_f8e11d58.mpeg',
      },
    ];

    let firstLoaded: Track | null = null;
    for (const s of samples) {
      try {
        const res = await fetch(s.url);
        if (res.ok) {
          const blob = await res.blob();
          const track: Track = {
            id: `sample_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
            title: s.title,
            artist: s.artist,
            album: s.album,
            duration: 180,
            sizeBytes: blob.size,
            format: 'MP3',
            mimeType: blob.type || 'audio/mpeg',
            source: 'SAMPLE_AUDIO',
            storageStatus: 'PERSISTENT',
            addedAt: Date.now(),
            bitrateKbps: 320,
            sampleRateHz: 48000,
            bitDepth: '16-bit',
            isFavorite: false,
          };
          const saved = await saveTrackToDB(track, blob);
          if (!firstLoaded) firstLoaded = saved;
          setTracks((prev) => [saved, ...prev]);
        }
      } catch {
        // ignore
      }
    }
    if (firstLoaded) {
      addToast('♪ Loaded Studio Acoustic Reels', 'success');
      playTrack(firstLoaded);
    }
  };

  const activeInlineFormatObj =
    AUDIOPHILE_FORMATS.find((f) => f.id === inlineFormat) || AUDIOPHILE_FORMATS[0];

  const openTuner = (query?: string, url?: string | null) => {
    setTunerQuery(query || '');
    setPrefilledUrl(url || null);
    setActivePage('tuner');
  };

  const playLastNotified = async (item: LastNotifiedListen) => {
    if (item.ytVideoId) {
      const existing = tracks.find((t) => t.ytVideoId === item.ytVideoId);
      if (existing) {
        await playTrack(existing);
        return;
      }
      const streamTrack: Track = {
        id: `yt_live_${item.ytVideoId}`,
        title: item.title || item.scheduleName,
        artist: item.scheduleName || 'YouTube',
        album: item.query
          ? `Online only · Fresh listen · ${item.query}`
          : 'Online only · Live YouTube (not downloaded)',
        duration: 0,
        sizeBytes: 0,
        format: 'YouTube',
        mimeType: 'video/youtube',
        source: 'YOUTUBE',
        storageStatus: 'DEVICE_LOCAL',
        addedAt: Date.now(),
        thumbnailUrl: `https://img.youtube.com/vi/${item.ytVideoId}/hqdefault.jpg`,
        bitrateKbps: 0,
        isFavorite: false,
        originalUrl: `https://www.youtube.com/watch?v=${item.ytVideoId}`,
        ytVideoId: item.ytVideoId,
      };
      const saved = await saveMetadataTrackToDB(streamTrack);
      setTracks((prev) => [saved, ...prev.filter((t) => t.id !== saved.id)]);
      logActivity({
        action: 'listen-live',
        label: `Listening live: "${saved.title}"`,
        result: 'online-only',
        format: 'YouTube',
        detail: 'Live YouTube stream — plays only with internet; no offline file, no background play',
        source: saved.originalUrl,
      });
      await playTrack(saved);
      return;
    }
    await playScheduledTarget({
      playlistId: item.playlistId,
      trackId: item.trackId,
      scheduleName: item.scheduleName,
      freshQuery: item.query,
      freshMode: item.freshMode || 'latest',
    });
  };

  const listenYoutubeInDeck = async (
    videoUrl: string,
    meta?: { title?: string; author?: string }
  ) => {
    const ytId = extractYouTubeId(videoUrl);
    if (!ytId) {
      addToast('Need a YouTube watch link to listen.', 'error');
      return;
    }
    const streamTrack: Track = {
      id: `yt_live_${ytId}`,
      title: meta?.title || `YouTube Track (${ytId})`,
      artist: meta?.author || 'YouTube',
      album: 'Online only · Live YouTube (not downloaded)',
      duration: 0,
      sizeBytes: 0,
      format: 'YouTube',
      mimeType: 'video/youtube',
      source: 'YOUTUBE',
      storageStatus: 'DEVICE_LOCAL',
      addedAt: Date.now(),
      thumbnailUrl: `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`,
      bitrateKbps: 0,
      isFavorite: false,
      originalUrl: `https://www.youtube.com/watch?v=${ytId}`,
      ytVideoId: ytId,
    };
    const saved = await saveMetadataTrackToDB(streamTrack);
    setTracks((prev) => [saved, ...prev.filter((t) => t.id !== saved.id)]);
    logActivity({
      action: 'listen-live',
      label: `Listening live: "${saved.title}"`,
      result: 'online-only',
      format: 'YouTube',
      detail: 'Live YouTube stream — plays only with internet; no offline file, no background play',
      source: saved.originalUrl,
    });
    await playTrack(saved);
    addToast(`♪ Playing "${saved.title}" (live · online only)`, 'info');
  };

  return (
    <div
      className={`min-h-screen flex flex-col bg-[#0e100d] text-[#f0ece1] relative overflow-hidden ${
        currentTrack
          ? showVideo && currentTrack.ytVideoId
            ? 'pb-[calc(8.75rem+7.5rem+env(safe-area-inset-bottom,0px))] md:pb-[calc(7rem+8rem)]'
            : 'pb-[calc(8.75rem+env(safe-area-inset-bottom,0px))] md:pb-28'
          : 'pb-[calc(4.5rem+env(safe-area-inset-bottom,0px))] md:pb-8'
      }`}
    >
      {/* Subtle Ambient Musical Glow when Music Plays */}
      <div
        className={`pointer-events-none fixed inset-0 transition-opacity duration-1000 ${
          isPlaying ? 'opacity-100' : 'opacity-30'
        }`}
        style={{
          background:
            'radial-gradient(circle at 50% 18%, rgba(184, 217, 158, 0.11) 0%, rgba(226, 201, 134, 0.05) 35%, transparent 70%)',
        }}
      />

      <header className="border-b border-[#262c22] bg-[#121510]/95 sticky top-0 z-30 backdrop-blur-md ogm-safe-top">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          <div
            onClick={() => {
              setActivePage('home');
              togglePlayPause();
            }}
            className="flex items-center gap-3 min-w-0 cursor-pointer group"
            title={isPlaying ? 'Pause' : 'Play'}
          >
            <GramophoneDiscLogo
              isPlaying={isPlaying}
              size={44}
              showHornOverlay={true}
              badgeFrame={true}
              title={isPlaying ? 'Disc spinning' : 'Open Grace Music'}
            />
            <div className="min-w-0">
              <div className="flex items-center gap-2">
                <span className={`cassette-led ${isPlaying ? 'cassette-led-on' : ''}`} />
                <h1 className="font-serif-display text-base sm:text-xl font-bold tracking-tight text-[#f0ece1] truncate">
                  Open Grace Music
                </h1>
              </div>
              <p className="text-[10px] sm:text-[11px] font-mono text-[#e2c986] tracking-wide uppercase break-words leading-snug">
                Dual-platform Audiophile Lossless Music
              </p>
            </div>
          </div>
          <AppPageNav active={activePage} onChange={setActivePage} variant="header" />
        </div>
      </header>

      {/* Main Musical Sanctuary Stage */}
      <main className="max-w-5xl mx-auto w-full flex-1 flex flex-col pt-5 px-4 sm:px-6 space-y-6 relative z-10 min-h-0">
        {activePage === 'home' && (
          <HomeListenDashboard
            libraryReady={libraryReady}
            playlists={playlists}
            tracks={tracks}
            lastNotified={lastNotified}
            isPlaying={isPlaying}
            currentTrack={currentTrack}
            listenQuery={heroListenQuery}
            onListenQueryChange={setHeroListenQuery}
            onListenSearch={(q) => openTuner(q)}
            onPlaySchedule={(pending) => void playScheduledTarget(pending)}
            onPlayNotified={(item) => void playLastNotified(item)}
            onOpenPage={setActivePage}
          />
        )}

        {activePage === 'tuner' && (
          <YouTubeBrowserModal
            isOpen
            presentation="page"
            initialUrl={prefilledUrl}
            initialQuery={tunerQuery}
            onClose={() => setActivePage('home')}
            onListenVideo={(videoUrl, meta) => void listenYoutubeInDeck(videoUrl, meta)}
            onConvertVideo={(videoUrl, meta) => {
              handleStartDownload(
                videoUrl,
                inlineFormat,
                inlineFormat === 'MP3' ? inlineMp3Bitrate : activeInlineFormatObj.bitrateKbps,
                inlineSaveToDevice,
                inlineCookies.trim() || undefined,
                meta?.title,
                meta?.author
              );
            }}
          />
        )}

        {activePage === 'schedule' && (
          <ScheduleModal
            isOpen
            presentation="page"
            playlists={playlists}
            tracks={tracks}
            onClose={() => setActivePage('home')}
            onPlayNow={(pending) => {
              void playScheduledTarget(pending);
            }}
          />
        )}

        {activePage === 'more' && (
          <MorePage
            converterApiOnline={converterApiOnline}
            converterUrlLabel={resolveConverterApiBaseUrl() || ''}
            isAndroid={isAndroid}
            isInstallable={isInstallable}
            isInstalled={isInstalled}
            onOpenSettings={() => setShowSettings(true)}
            onOpenInstall={() => setShowInstallGuide(true)}
            onOpenAndroidProject={() => setShowAndroidProject(true)}
            onOpenActivityLog={() => setShowActivityLog(true)}
            onPwaInstall={() => void install()}
          />
        )}

        {activePage === 'library' && (
        <>
        {/* Studio Master Tape Deck (Streamlined URL / YouTube Recorder) */}
        <section className="cassette-card rounded-3xl p-5 sm:p-6 space-y-4">
          {converterApiOnline === false && (
            <div className="p-3 rounded-xl bg-[#2a2416] border border-[#524929] flex items-start gap-2 text-xs text-[#fcd34d]">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <p className="leading-snug">
                Converter API is not reachable at {resolveConverterApiBaseUrl() || '(no server set)'}.
                Check Render is up, your network connection, or set a self-hosted URL in Settings (
                <code className="text-[#b8d99e]">npm start</code>).
              </p>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2.5">
              <span className="cassette-led cassette-led-rec" />
              <h3 className="font-serif-display text-base sm:text-lg font-bold text-[#f0ece1]">
                Studio Master Tape Recorder
              </h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setInlineSaveToDevice(!inlineSaveToDevice)}
                className={`cassette-btn px-2.5 py-1 text-[11px] font-mono ${
                  inlineSaveToDevice ? 'cassette-btn-engaged' : 'text-[#9fa396]'
                }`}
              >
                <span className={`cassette-led ${inlineSaveToDevice ? 'cassette-led-on' : ''}`} />
                <span>AUTO-SAVE .{activeInlineFormatObj.extension.toUpperCase()}</span>
              </button>

              <button
                type="button"
                onClick={() => setShowInlineCookies(!showInlineCookies)}
                className={`cassette-btn px-2.5 py-1 text-[11px] font-mono ${
                  showInlineCookies ? 'cassette-btn-engaged' : 'text-[#9fa396]'
                }`}
                title="Optional Studio Cookie Key"
              >
                <KeyRound className="w-3 h-3 text-[#e2c986]" />
              </button>
            </div>
          </div>

          {/* Tape Bias / Format Selector Keys */}
          <div className="cassette-bank grid grid-cols-2 sm:grid-cols-5 gap-1.5">
            {AUDIOPHILE_FORMATS.map((fmt) => {
              const selected = inlineFormat === fmt.id;
              return (
                <button
                  key={fmt.id}
                  type="button"
                  disabled={isDownloading}
                  onClick={() => setInlineFormat(fmt.id)}
                  className={`cassette-btn flex-col items-start px-3 py-2 text-left ${
                    selected ? 'cassette-btn-engaged' : ''
                  }`}
                >
                  <div className="w-full flex items-center justify-between">
                    <span className="font-mono text-xs font-bold">{fmt.id}</span>
                    <span className={`cassette-led ${selected ? 'cassette-led-on' : ''}`} />
                  </div>
                  <div className="text-[10px] font-mono text-[#9fa396] mt-0.5 truncate w-full">
                    {fmt.badge}
                  </div>
                </button>
              );
            })}
          </div>

          {studioFormatWarning(inlineFormat) && (
            <p className="text-[11px] font-mono text-[#e2c986] leading-snug">
              {studioFormatWarning(inlineFormat)}
            </p>
          )}

          {/* URL Slot + Record Cassette Key */}
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="cassette-window flex-1 flex items-center rounded-2xl p-1.5">
              <input
                type="text"
                value={inlineUrl}
                onChange={(e) => {
                  setInlineUrl(e.target.value);
                  validateInlineUrl(e.target.value);
                }}
                disabled={isDownloading}
                placeholder="Paste YouTube or Audio URL to record onto master tape..."
                className="flex-1 bg-transparent px-3 py-2 text-[#f0ece1] placeholder-[#686b60] text-xs sm:text-sm focus:outline-none font-mono"
              />
              <button
                type="button"
                onClick={handleInlinePaste}
                disabled={isDownloading}
                className="cassette-btn px-3 py-2 text-xs font-mono text-[#b8d99e] shrink-0"
              >
                <Clipboard className="w-3.5 h-3.5" />
                <span>PASTE</span>
              </button>
            </div>

            <button
              type="button"
              disabled={!inlineUrl.trim() || isDownloading}
              onClick={() =>
                handleStartDownload(
                  inlineUrl,
                  inlineFormat,
                  inlineFormat === 'MP3' ? inlineMp3Bitrate : activeInlineFormatObj.bitrateKbps,
                  inlineSaveToDevice,
                  inlineCookies.trim() || undefined,
                  inlinePreview?.title,
                  inlinePreview?.author
                )
              }
              className="cassette-btn cassette-btn-primary px-6 py-3 text-xs sm:text-sm font-mono uppercase tracking-wider disabled:opacity-40 shrink-0"
            >
              {isDownloading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>RECORDING {inlineFormat}...</span>
                </>
              ) : (
                <>
                  <Radio className="w-4 h-4" />
                  <span>⏺ RECORD {inlineFormat}</span>
                </>
              )}
            </button>
          </div>

          {inlineFormat === 'MP3' && (
            <div className="cassette-bank inline-flex items-center gap-1.5">
              <span className="text-[11px] font-mono text-[#9fa396] px-2">MP3 BIAS:</span>
              {[320, 256, 192].map((br) => (
                <button
                  key={br}
                  type="button"
                  onClick={() => setInlineMp3Bitrate(br)}
                  className={`cassette-btn px-2.5 py-1 text-[11px] font-mono ${
                    inlineMp3Bitrate === br ? 'cassette-btn-engaged' : ''
                  }`}
                >
                  {br}K
                </button>
              ))}
            </div>
          )}

          {showInlineCookies && (
            <div className="cassette-window p-3 rounded-xl">
              <textarea
                rows={2}
                value={inlineCookies}
                onChange={(e) => setInlineCookies(e.target.value)}
                placeholder="Paste youtube.com cookies (Netscape export or Cookie header) if YouTube blocks the server…"
                className="w-full bg-transparent text-[11px] font-mono text-[#f0ece1] placeholder-[#686b60] focus:outline-none"
              />
            </div>
          )}

          {/* Live URL Validation & Monitor */}
          {isValidatingInline && (
            <div className="cassette-window p-3 rounded-xl flex items-center gap-2 text-xs font-mono text-[#b8d99e]">
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>TUNING STREAM SIGNAL...</span>
            </div>
          )}

          {inlineValidationError && !isValidatingInline && (
            <div className="p-3 rounded-xl bg-[#2a1616] border border-[#522929] flex items-center gap-2 text-xs text-[#fca5a5]">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{inlineValidationError}</span>
            </div>
          )}

          {inlinePreview && (
            <div className="cassette-window rounded-2xl p-4 grid grid-cols-1 md:grid-cols-2 gap-4 items-center">
              <div className="space-y-2">
                <div className="inline-flex items-center gap-2 text-[11px] font-mono text-[#b8d99e]">
                  <span className="cassette-led cassette-led-on" />
                  <span>SIGNAL LOCKED · {inlineFormat} ({activeInlineFormatObj.badge})</span>
                </div>
                <h4 className="font-serif-display text-base sm:text-lg font-bold text-[#f0ece1]">
                  {inlinePreview.title}
                </h4>
                <p className="text-xs font-mono text-[#e2c986]">
                  {inlinePreview.author}
                </p>
              </div>

              {inlinePreview.isYouTube && (
                <div
                  className="relative w-full rounded-xl overflow-hidden border border-[#272c23] bg-[#0e0f0d] min-h-[200px]"
                  style={{ aspectRatio: '16 / 9' }}
                >
                  <iframe
                    src={`https://www.youtube-nocookie.com/embed/${inlinePreview.id}?playsinline=1&rel=0&modestbranding=1&enablejsapi=1&origin=${encodeURIComponent(typeof window !== 'undefined' ? window.location.origin : '')}`}
                    title="YouTube Monitor"
                    className="absolute inset-0 w-full h-full border-0"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; fullscreen"
                    allowFullScreen
                  />
                </div>
              )}
            </div>
          )}

          {isDownloading && (
            <div className="cassette-window p-3.5 rounded-xl space-y-2">
              <div className="flex items-center justify-between text-xs font-mono text-[#b8d99e]">
                <span className="flex items-center gap-2">
                  <span className="cassette-led cassette-led-rec animate-ping" />
                  <span>{downloadStatus}</span>
                </span>
                <span>{Math.round(downloadProgress * 100)}%</span>
              </div>
              <div className="w-full h-2 bg-[#161a13] rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-[#b8d99e] to-[#e2c986] transition-all duration-200 rounded-full"
                  style={{ width: `${Math.round(downloadProgress * 100)}%` }}
                />
              </div>
            </div>
          )}

          {downloadError && !isDownloading && (
            <div className="p-3.5 rounded-xl bg-[#2a1616] border border-[#522929] flex items-start gap-2.5 text-xs text-[#fca5a5]">
              <span className="cassette-led cassette-led-rec shrink-0 mt-1" />
              <div className="min-w-0">
                <p className="font-mono font-bold uppercase tracking-wide">Recording failed</p>
                <p className="mt-1 leading-snug">{downloadError}</p>
              </div>
            </div>
          )}
        </section>

        {/* Cassette Library — all downloads & imports */}
        <section id="cassette-library" className="scroll-mt-24 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-2">
            <div>
              <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-[#f0ece1]">
                Cassette Library
              </h2>
              <p className="text-xs font-mono text-[#b8d99e] mt-0.5">
                Your downloads &amp; imports · {tracks.length} track{tracks.length === 1 ? '' : 's'}
              </p>
            </div>
          </div>
        </section>

        <section className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="cassette-bank flex items-center gap-1.5 overflow-x-auto scrollbar-none">
            {(
              [
                { id: 'ALL', label: 'ALL MUSIC', count: tracks.length },
                {
                  id: 'LOSSLESS',
                  label: 'LOSSLESS',
                  count: tracks.filter((t) =>
                    ['FLAC', 'ALAC', 'DSD', 'WAV'].includes(t.format.toUpperCase())
                  ).length,
                },
                {
                  id: 'DOWNLOADS',
                  label: 'DOWNLOADS',
                  count: tracks.filter(
                    (t) => t.source === 'YOUTUBE' || t.source === 'DIRECT_URL'
                  ).length,
                },
                {
                  id: 'DEVICE_MUSIC',
                  label: 'DEVICE',
                  count: tracks.filter(
                    (t) => t.source === 'LOCAL_IMPORT' || t.source === 'SAMPLE_AUDIO'
                  ).length,
                },
                {
                  id: 'MP3',
                  label: 'MP3 320K',
                  count: tracks.filter(
                    (t) => t.format.toUpperCase() === 'MP3' || t.mimeType.includes('mpeg')
                  ).length,
                },
                {
                  id: 'FAVORITES',
                  label: '♥ FAVORITES',
                  count: tracks.filter((t) => t.isFavorite).length,
                },
              ] as const
            ).map((tab) => {
              const active = selectedTab === tab.id && !selectedPlaylistId;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    setSelectedPlaylistId(null);
                    setSelectedTab(tab.id);
                  }}
                  className={`cassette-btn px-3 py-1.5 text-xs font-mono whitespace-nowrap ${
                    active ? 'cassette-btn-engaged' : 'text-[#9fa396]'
                  }`}
                >
                  <span className={`cassette-led ${active ? 'cassette-led-on' : ''}`} />
                  <span>{tab.label}</span>
                  <span className="text-[10px] text-[#e2c986]">({tab.count})</span>
                </button>
              );
            })}
            {playlists.map((pl) => {
              const active = selectedPlaylistId === pl.id;
              return (
                <div
                  key={pl.id}
                  className={`cassette-btn px-2 py-1.5 text-xs font-mono whitespace-nowrap ${
                    active ? 'cassette-btn-engaged' : 'text-[#9fa396]'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedPlaylistId(pl.id)}
                    className="flex items-center gap-1.5 min-w-0"
                  >
                    <span className={`cassette-led ${active ? 'cassette-led-on' : ''}`} />
                    <ListMusic className="w-3 h-3 text-[#e2c986] shrink-0" />
                    <span className="max-w-[9rem] truncate">{pl.name}</span>
                    <span className="text-[10px] text-[#e2c986]">({pl.trackIds.length})</span>
                  </button>
                  <button
                    type="button"
                    title={`Remove ${pl.name}`}
                    onClick={(e) => handleDeleteMix(pl.id, e)}
                    className="p-0.5 text-[#686b60] hover:text-[#f87171]"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              );
            })}
            <button
              type="button"
              onClick={() => openPlaylistPicker(null)}
              className="cassette-btn px-3 py-1.5 text-xs font-mono whitespace-nowrap text-[#e2c986]"
            >
              <Plus className="w-3 h-3" />
              <span>NEW MIX</span>
            </button>
            <button
              type="button"
              onClick={() => setActivePage('schedule')}
              className="cassette-btn px-3 py-1.5 text-xs font-mono whitespace-nowrap text-[#b8d99e]"
            >
              <Bell className="w-3 h-3" />
              <span>SCHEDULE</span>
            </button>
          </div>

          <div className="cassette-window flex items-center px-3 py-1.5 rounded-xl min-w-[220px]">
            <Search className="w-3.5 h-3.5 text-[#686b60] shrink-0" />
            <input
              type="text"
              placeholder="Find tape..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-2 pr-2 py-1 bg-transparent text-[#f0ece1] placeholder-[#686b60] text-xs font-mono focus:outline-none"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="text-xs text-[#9fa396] hover:text-[#f0ece1]"
              >
                ✕
              </button>
            )}
          </div>
        </section>

        {/* Cassette Tape Library */}
        <section className="flex-1 pb-6">
          {filteredTracks.length === 0 ? (
            <div className="py-12 px-6 rounded-3xl cassette-card flex flex-col items-center justify-center text-center max-w-md mx-auto space-y-5">
              {/* Mini Cassette Reel Graphic */}
              <div className="cassette-window px-6 py-4 rounded-2xl flex items-center gap-5">
                <svg viewBox="0 0 40 40" className="w-9 h-9 text-[#b8d99e] animate-spin-reel">
                  <circle cx="20" cy="20" r="16" fill="#10130e" stroke="currentColor" strokeWidth="2.2" />
                  <circle cx="20" cy="20" r="6" fill="none" stroke="#e2c986" strokeWidth="1.8" strokeDasharray="3 3" />
                  <line x1="20" y1="4" x2="20" y2="12" stroke="currentColor" strokeWidth="2" />
                  <line x1="20" y1="28" x2="20" y2="36" stroke="currentColor" strokeWidth="2" />
                  <line x1="4" y1="20" x2="12" y2="20" stroke="currentColor" strokeWidth="2" />
                  <line x1="28" y1="20" x2="36" y2="20" stroke="currentColor" strokeWidth="2" />
                </svg>
                <span className="font-serif-display text-2xl text-[#e2c986]">♪</span>
                <svg viewBox="0 0 40 40" className="w-9 h-9 text-[#e2c986] animate-spin-reel">
                  <circle cx="20" cy="20" r="16" fill="#10130e" stroke="currentColor" strokeWidth="2.2" />
                  <circle cx="20" cy="20" r="6" fill="none" stroke="#b8d99e" strokeWidth="1.8" strokeDasharray="3 3" />
                  <line x1="20" y1="4" x2="20" y2="12" stroke="currentColor" strokeWidth="2" />
                  <line x1="20" y1="28" x2="20" y2="36" stroke="currentColor" strokeWidth="2" />
                  <line x1="4" y1="20" x2="12" y2="20" stroke="currentColor" strokeWidth="2" />
                  <line x1="28" y1="20" x2="36" y2="20" stroke="currentColor" strokeWidth="2" />
                </svg>
              </div>

              <h3 className="font-serif-display text-xl font-bold text-[#f0ece1]">
                {selectedPlaylistId
                  ? playlists.find((p) => p.id === selectedPlaylistId)?.name || 'Empty mix'
                  : 'Insert Your First Master Tape'}
              </h3>
              <p className="text-xs font-mono text-[#9fa396] max-w-sm">
                {selectedPlaylistId
                  ? 'This mix is empty. Open ALL MUSIC, then tap the list button on a tape to drop it here.'
                  : 'Recorded tracks from YouTube, URLs, and imports appear in your Cassette Library above.'}
              </p>

              {!selectedPlaylistId ? (
              <div className="cassette-bank flex flex-wrap items-center justify-center gap-2">
                <button
                  onClick={handleLoadSampleTracks}
                  className="cassette-btn cassette-btn-primary px-4 py-2.5 text-xs font-mono"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>▶ PLAY STUDIO SAMPLES</span>
                </button>

<button
                  type="button"
                  disabled={!!importProgress}
                  onClick={() => {
                    addToast('Opening file picker…', 'info');
                    filePickerRef.current?.click();
                  }}
                  className="cassette-btn px-4 py-2.5 text-xs font-mono text-[#f0ece1]"
                >
                  <FolderOpen className="w-3.5 h-3.5 text-[#b8d99e]" />
                  <span>
                    {importProgress
                      ? `Importing ${importProgress.done + 1}/${importProgress.total}`
                      : '⏏ LOAD DEVICE FILES'}
                  </span>
                </button>
                {supportsFolderPick && (
                  <button
                    type="button"
                    disabled={!!importProgress}
                    onClick={() => folderPickerRef.current?.click()}
                    className="cassette-btn px-4 py-2.5 text-xs font-mono text-[#f0ece1]"
                  >
                    <FolderOpen className="w-3.5 h-3.5 text-[#b8d99e]" />
                    <span>IMPORT FOLDER</span>
                  </button>
                )}
                <input
                  ref={filePickerRef}
                  type="file"
                  multiple
                  accept="audio/*"
                  onChange={handleLocalFiles}
                  style={{ position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', pointerEvents: 'none' }}
                  tabIndex={-1}
                  aria-hidden="true"
                />
                <input
                  ref={folderPickerRef}
                  type="file"
                  multiple
                  // @ts-expect-error non-standard attribute
                  webkitdirectory=""
                  onChange={handleLocalFiles}
                  style={{ position: 'absolute', width: 1, height: 1, opacity: 0, overflow: 'hidden', pointerEvents: 'none' }}
                  tabIndex={-1}
                  aria-hidden="true"
                />
                {importProgress && (
                  <p className="w-full text-center text-[10px] font-mono text-[#9fa396] truncate">
                    {importProgress.name}
                  </p>
                )}
                <p className="w-full text-center text-[10px] font-mono text-[#7d8174]">
                  Pick several songs at once (hold a tap to multi-select).
                  {supportsFolderPick ? ' Folder import reads every audio file inside.' : ' Whole-folder import is not available in this app; select multiple files instead.'}
                </p>
              </div>
              ) : (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedPlaylistId(null);
                    setSelectedTab('ALL');
                  }}
                  className="cassette-btn cassette-btn-primary px-4 py-2.5 text-xs font-mono"
                >
                  <span>BACK TO LIBRARY</span>
                </button>
              )}
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTracks.map((track) => (
                <TrackCard
                  key={track.id}
                  track={track}
                  isPlayingThis={currentTrack?.id === track.id}
                  isCurrentlyPlaying={isPlaying}
                  isConverting={convertingTrackId === track.id}
                  conversionProgress={convertingProgress}
                  onPlayClick={() => playTrack(track)}
                  onConvertToMp3={() => handleConvertToMp3(track)}
                  onLyricsClick={() => setSelectedTrackForLyrics(track)}
                  onExportClick={() => handleExportTrack(track)}
                  onDeleteClick={() => handleDeleteTrack(track)}
                  onToggleFavorite={() => handleToggleFavorite(track)}
                  onAddToPlaylist={() => openPlaylistPicker(track.id)}
                />
              ))}
            </div>
          )}
        </section>
        </>
        )}
      </main>

      {/* Docked Cassette Transport Bar */}
      <NowPlayingBar
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        isShuffle={isShuffle}
        loopMode={loopMode}
        volume={volume}
        onTogglePlayPause={togglePlayPause}
        onPrevious={handlePrevTrack}
        onNext={handleNextTrack}
        onSeek={handleSeek}
        onToggleShuffle={() => setIsShuffle(!isShuffle)}
        onCycleLoop={cycleLoopMode}
        onVolumeChange={handleVolumeChange}
        onOpenFullPlayer={() => setShowFullPlayer(true)}
        showVideo={showVideo}
        onShowVideoChange={setShowVideo}
        dockClassName="bottom-[calc(3.65rem+env(safe-area-inset-bottom,0px))] md:bottom-0"
      />
      <AppPageNav active={activePage} onChange={setActivePage} variant="bottom" />

      {/* Full Screen Gramophone Turntable + Live Frequency Equalizer */}
      <FullPlayerModal
        isOpen={showFullPlayer}
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        currentTime={currentTime}
        duration={duration}
        isShuffle={isShuffle}
        loopMode={loopMode}
        playbackSpeed={playbackSpeed}
        volume={volume}
        queue={tracks}
        onClose={() => setShowFullPlayer(false)}
        onTogglePlayPause={togglePlayPause}
        onPrevious={handlePrevTrack}
        onNext={handleNextTrack}
        onSeek={handleSeek}
        onToggleShuffle={() => setIsShuffle(!isShuffle)}
        onCycleLoop={cycleLoopMode}
        onSetSpeed={handleSpeedChange}
        onVolumeChange={handleVolumeChange}
        onSelectTrack={(t) => playTrack(t)}
        onExportTrack={handleExportTrack}
        onOpenLyrics={(t) => setSelectedTrackForLyrics(t)}
        showVideo={showVideo}
        onShowVideoChange={setShowVideo}
      />

      {/* Master Tape Deck Recorder Dialog */}
      <DownloadDialog
        isOpen={showDownloadDialog}
        initialUrl={prefilledUrl}
        isDownloading={isDownloading}
        downloadProgress={downloadProgress}
        downloadStatus={downloadStatus}
        downloadError={downloadError}
        onClose={() => {
          setShowDownloadDialog(false);
          setDownloadError(null);
        }}
        onStartDownload={handleStartDownload}
        onOpenYouTubeBrowser={(url) => {
          setShowDownloadDialog(false);
          openTuner('', url || null);
        }}
      />

      {/* Vocal Lyrics & Instrument Chord Sheet Modal */}
      <LyricsModal
        isOpen={!!selectedTrackForLyrics}
        track={selectedTrackForLyrics}
        onClose={() => setSelectedTrackForLyrics(null)}
        onListenRelated={(query) => {
          setSelectedTrackForLyrics(null);
          openTuner(query);
        }}
      />

      <AndroidProjectModal
        isOpen={showAndroidProject}
        onClose={() => setShowAndroidProject(false)}
        onOpenInstallGuide={() => {
          setShowAndroidProject(false);
          setShowInstallGuide(true);
        }}
      />

      <SettingsModal
        isOpen={showSettings}
        onClose={() => setShowSettings(false)}
        onSaved={refreshConverterHealth}
      />

      <InstallGuideModal
        isOpen={showInstallGuide}
        onClose={() => setShowInstallGuide(false)}
        isAndroid={isAndroid}
        isInstallable={isInstallable}
        onPwaInstall={install}
      />

      <ActivityLogModal isOpen={showActivityLog} onClose={() => setShowActivityLog(false)} />

      <PlaylistPickerModal
        isOpen={showPlaylistPicker}
        trackTitle={tracks.find((t) => t.id === playlistPickerTrackId)?.title}
        playlists={playlists}
        onClose={closePlaylistPicker}
        onCreate={handleCreateMix}
        onPick={handlePickMix}
      />

      {/* Global Toast Notification System */}
      <Toast toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
